# Swift-Challenge2023

[![forthebadge](https://forthebadge.com/images/badges/built-with-love.svg)](https://forthebadge.com)
[![forthebadge](https://forthebadge.com/images/badges/made-with-swift.svg)](https://forthebadge.com)
# Desciption :
my very first Swift challenge 
A simple Tic Tac Toe Game made with 100% Swift UI 

<h3 align="left">Support:</h3>
<p><a href="https://www.buymeacoffee.com/https://bmc.link/maxime21160"> <img align="left" src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" height="50" width="210" alt="https://bmc.link/maxime21160" /></a></p><br><br>

# Frameworks use in this project :


Welcome-Sheet: https://github.com/MAJKFL/Welcome-Sheet. 


ConfettiSwiftUI: https://github.com/simibac/ConfettiSwiftUI. 


AlertToast: https://github.com/elai950/AlertToast


Shiny: https://github.com/maustinstar/shiny


# Support :
📱 works from iOS 14 (older iOS not tested may work ) to iOS 16 


# Who made this :
Made with ❤️ by Max21910 in 🇫🇷


# Description
My 2023 swift challenge participation


## Free to use ?
yes this project is open source (please do not use this as a participation project for the 2023 swift challenge)
## Image :
<img src="img/1.jpeg" width="252" alt="image 1"><img src="img/2.jpeg" width="252" alt="image 2"><img src="img/3.jpeg" width="252" alt="image 3">
<img src="img/4.jpeg" width="252" alt="image 4"><img src="img/5.jpeg" width="252" alt="image 5"><img src="img/6.jpeg" width="252" alt="image 6">
<img src="img/7.jpeg" width="252" alt="image 7"><img src="img/8.jpeg" width="252" alt="image 8"><img src="img/9.jpeg" width="252" alt="image 9">
<img src="img/banner.png" width="252" alt="Banner">
## Contributeurs

- Created by [max21910](https://github.com/max21910)

## Remarque

 N'hésitez pas à contribuer au projet en soumettant des pull requests ou en signalant des problèmes. Toute contribution est la bienvenue !



<h3 align="left">Connect with me:</h3>
<p align="left">
<a href="https://twitter.com/max21160" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/twitter.svg" alt="max21160" height="30" width="40" /></a>
<a href="https://instagram.com/maxime_dpj" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="maxime_dpj" height="30" width="40" /></a>
<a href="https://medium.com/max21160" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/medium.svg" alt="max21160" height="30" width="40" /></a>
<a href="https://www.youtube.com/c/max_studio" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/youtube.svg" alt="max_studio" height="30" width="40" /></a>
</p>



