//
//  Frameworks.swift
//  Tic Tac Toe Game
//
//  Created by Max  on 05/04/2023.
//

import SwiftUI

struct Frameworks: View {
    var body: some View {
        NavigationView {
            
        }
        .navigationTitle("Frameworks")
    }
}

struct Frameworks_Previews: PreviewProvider {
    static var previews: some View {
        Frameworks()
    }
}
