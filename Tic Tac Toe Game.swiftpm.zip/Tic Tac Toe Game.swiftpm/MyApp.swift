//
//  MyApp.swift
//  Tic Tac Toe Game
//
//  Created by Max  on 31/03/2023.
//
import SwiftUI
@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            VStack {
                Prelaunch() //custom launch animation
               
            }
        }
    }
}
