//
//  PlayeName.swift
//  Tic Tac Toe Game
//
//  Created by Max  on 01/04/2023.
//
import SwiftUI
struct PlayerNamesView: View {
    

    var body: some View {
        VStack {
            NavigationView {
                Text("Settings")
            }
            .padding()
        }
    }
}
struct PlayerNamesView_Previews: PreviewProvider {
    static var previews: some View {
        PlayerNamesView()
    }
}
